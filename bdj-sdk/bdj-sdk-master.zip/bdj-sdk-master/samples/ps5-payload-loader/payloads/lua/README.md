Usage example:
```console
$ nc -q0 ps5 9938 < helloworld.lua
```
