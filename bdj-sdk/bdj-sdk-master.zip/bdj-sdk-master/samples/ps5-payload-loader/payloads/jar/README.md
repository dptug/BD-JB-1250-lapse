To list all java properties:
```console
$ make
$ export PS5_HOST=ps5
$ export PS5_PORT=9025
$ make test_props
```
