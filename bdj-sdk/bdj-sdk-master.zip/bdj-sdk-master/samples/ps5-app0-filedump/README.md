# PS5 app0 filedump
This is a proof of concept BD-J Xlet that dumps the /app0 directory from the
PS5 BD-J player. The Xlet relies on a [privilege escalation vulnerability][h1]
discovered by [theflow][theflow], which was later [reproduced for the PS4][insp]
by [sleirsgoevy][sleirsgoevy].

[h1]: https://hackerone.com/reports/1379975
[insp]: https://github.com/sleirsgoevy/bd-jb
[sleirsgoevy]: https://github.com/sleirsgoevy
[theflow]: https://github.com/TheOfficialFloW
